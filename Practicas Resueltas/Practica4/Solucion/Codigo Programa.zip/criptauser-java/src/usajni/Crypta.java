package usajni;

public class Crypta {

	  public native String crypta(String key, String salt);
	  
}
