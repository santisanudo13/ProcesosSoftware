package usajni;

public interface JCriptInterface {

	String crypta(String clave, String sal);

}
